export const COMPANY_NAV = [
  {
    name: 'Who We Are',
    href: '/company/whoweare',
    description: 'Our story, mission, and values',
  },
  {
    name: 'Why Us',
    href: '/company/whyus',
    description: 'What makes us different',
  },
  {
    name: 'Our Team',
    href: '/company/ourteam',
    description: 'Meet the people behind the product',
  },
  {
    name: 'Our Partners',
    href: '/company/ourpartners',
    description: 'Trusted partners worldwide',
  },
];
